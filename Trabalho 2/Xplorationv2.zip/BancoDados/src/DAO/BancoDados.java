package DAO;
import EDA.Planetas;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import DAO.BancoDados;
import EDA.Paciente;
import EDA.Funcionarios;

/**
 * @author UDESC
 */
public class BancoDados {
    static Connection c = null;
    
    private boolean conectar(){
        try {
            //Class.forName("org.postgresql.Driver");
            c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Xploration",
                                            "postgres", "udesc");
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println(e.getClass().getName()+": "+e.getMessage());
            return false;
        }
        return true;
    }
    
     public ArrayList<Planetas> getPlanetas(){
        if( !conectar() ) return null;
        ArrayList<Planetas> resultado = new ArrayList();
        try{
            Statement stmt = null;
            stmt = c.createStatement();
            String sql = "SELECT * FROM Planeta";
            ResultSet rs = stmt.executeQuery( sql );
            while ( rs.next() ) {
                int idp = rs.getInt("idp");
                String  nome = rs.getString("nome");
                int  qtdpessoasphe = rs.getInt("qtdpessoasphe");
                String localizacao = rs.getString("localizacao");
                resultado.add(new Planetas(idp, nome, qtdpessoasphe, localizacao) );
            }
            rs.close();
            stmt.close();
            c.close();
        } catch ( Exception e ) {
            System.err.println( "ERRO DURANTE CONSULTA: getPlaneta");
            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
        }
        return resultado;
    }
     
     public ArrayList<Funcionarios> getFuncionarios(){
        if( !conectar() ) return null;
        ArrayList<Funcionarios> resultado = new ArrayList();
        try{
            Statement stmt = null;
            stmt = c.createStatement();
            String sql = "SELECT * FROM Funcionarios ORDER BY salario";
            ResultSet rs = stmt.executeQuery( sql );
            while ( rs.next() ) {
                int idf = rs.getInt("idf");
                float salario = rs.getFloat("salario");
                String endereco = rs.getString("endereco");
                String genero = rs.getString("genero");
                String nome = rs.getString("nome");
                resultado.add(new Funcionarios(idf, salario, endereco, genero, nome));
            }
            rs.close();
            stmt.close();
            c.close();
        } catch ( Exception e ) {
            System.err.println( "ERRO DURANTE CONSULTA: getFucionarioss");
            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
        }
        return resultado;
    }
    
    public ArrayList<Paciente> getPacientes(){
        if( !conectar() ) return null;
        ArrayList<Paciente> resultado = new ArrayList();
        try{
            Statement stmt = null;
            stmt = c.createStatement();
            String sql = "SELECT * FROM pacientes";
            ResultSet rs = stmt.executeQuery( sql );
            while ( rs.next() ) {
                int codp = rs.getInt("codp");
                String  name = rs.getString("nome");
                String  cpf = rs.getString("cpf");
                int idade  = rs.getInt("idade");
                String cidade = rs.getString("cidade");
                resultado.add( new Paciente(codp, name, cpf, idade, cidade) );
            }
            rs.close();
            stmt.close();
            c.close();
        } catch ( Exception e ) {
            System.err.println( "ERRO DURANTE CONSULTA: getPacientes");
            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
        }
        return resultado;
    }
    
    
    public Paciente getPaciente(int codigo){
        if( !conectar() ) return null;
        Paciente resultado = null;
        try{
            Statement stmt = null;
            stmt = c.createStatement();
            String sql = "SELECT * FROM pacientes WHERE codp = "+codigo;
            ResultSet rs = stmt.executeQuery( sql );
            while ( rs.next() ) {
                
                int codp = rs.getInt("codp");
                String  name = rs.getString("nome");
                String  cpf = rs.getString("cpf");
                int idade  = rs.getInt("idade");
                String cidade = rs.getString("cidade");
                resultado = new Paciente(codp, name, cpf, idade, cidade);
            }
            rs.close();
            stmt.close();
            c.close();
        } catch ( Exception e ) {
            System.err.println( "ERRO DURANTE CONSULTA: getPaciente");
            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
        }
        return resultado;
    }
    
    public Funcionarios getFuncionarios(int idfun){
        if( !conectar() ) return null;
        Funcionarios resultado = null;
        try{
            Statement stmt = null;
            stmt = c.createStatement();
            String sql = "SELECT * FROM Funcionarios WHERE idf = "+idfun;
            ResultSet rs = stmt.executeQuery( sql );
            while ( rs.next() ) {
                int idf = rs.getInt("idf");
                float salario = rs.getFloat("salario");
                String endereco = rs.getString("endereco");
                String genero = rs.getString("genero");
                String nome = rs.getString("nome");
                resultado = new Funcionarios(idf, salario, endereco, genero, nome);
            }
            rs.close();
            stmt.close();
            c.close();
        } catch ( Exception e ) {
            System.err.println( "ERRO DURANTE CONSULTA: getFuncionarios");
            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
        }
        return resultado;
    }
    
    
    
    public boolean cadastrarPaciente(Paciente p){
        if( !conectar() ) return false;
        Paciente resultado = null;
        try{
            Statement stmt = null;
            stmt = c.createStatement();
            String sql = "INSERT INTO pacientes (codp, nome, cpf, idade, cidade)"
                    + "VALUES ("+p.codp+", '"+p.nome+"', '"+p.cpf+"', "+p.idade+", '"+p.cidade+"')";
            stmt.executeUpdate( sql );
            stmt.close();
            c.close();
        } catch ( Exception e ) {
            System.err.println( "ERRO DURANTE INSERÇÃO: cadastrarPaciente");
            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
            return false;
        }
        return true;
    }
    
    
    
    public boolean alterarFuncionarios(Funcionarios f){
        if( !conectar() ) return false;
        Funcionarios resultado = null;
        try{
            Statement stmt = null;
            stmt = c.createStatement();
            String sql = "UPDATE Funcionarios SET nome = '"+f.nome+"', genero = '"+f.genero+"', "
                    + "salario = "+f.salario+", endereco = '"+f.endereco+"' "
                    + "WHERE idf = "+f.idf;
            stmt.executeUpdate( sql );
            stmt.close();
            c.close();
        } catch ( Exception e ) {
            System.err.println( "ERRO DURANTE ATUALIZAÇÃO: alterarFuncionarios");
            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
            return false;
        }
        return true;
    }

    public boolean CadastrarFuncionario(Funcionarios f) {
         //To change body of generated methods, choose Tools | Templates.
         if( !conectar() ) return false;
        Funcionarios resultado = null;
        try{
            Statement stmt = null;
            stmt = c.createStatement();
            String sql = "INSERT INTO Funcionarios (idf, salario, endereco, genero, nome)"
                    + "VALUES ("+f.idf+", '"+f.salario+"', '"+f.endereco+"', " +f.genero+", '"+f.nome+"')";
            stmt.executeUpdate( sql );
            stmt.close();
            c.close();
        } catch ( Exception e ) {
            System.err.println( "ERRO DURANTE INSERÇÃO: cadastrarFuncionario");
            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
            return false;
        }
        return true;
    }

    
}
