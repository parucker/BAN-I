package DAO;
import EDA.Planetas;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import EDA.Paciente;
import EDA.Funcionarios;
import java.sql.SQLException;

/**
 * @author UDESC
 */
public class BancoDados {
    static Connection c = null;
    
    private boolean conectar(){
        try {
            //Class.forName("org.postgresql.Driver");
            c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Xploration",
                                            "postgres", "udesc");
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println(e.getClass().getName()+": "+e.getMessage());
            return false;
        }
        return true;
    }
    
     public ArrayList<Planetas> getPlanetas(){
        if( !conectar() ) return null;
        ArrayList<Planetas> resultado = new ArrayList();
        try{
            Statement stmt = null;
            stmt = c.createStatement();
            String sql = "SELECT * FROM Planeta";
            ResultSet rs = stmt.executeQuery( sql );
            while ( rs.next() ) {
                int idp = rs.getInt("idp");
                String  nome = rs.getString("nome");
                int  qtdpessoasphe = rs.getInt("qtdpessoasphe");
                String localizacao = rs.getString("localizacao");
                resultado.add(new Planetas(idp, nome, qtdpessoasphe, localizacao) );
            }
            rs.close();
            stmt.close();
            c.close();
        } catch ( Exception e ) {
            System.err.println( "ERRO DURANTE CONSULTA: getPlaneta");
            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
        }
        return resultado;
    }
    
    public Planetas getPlanetas(int idplaneta){
        if( !conectar() ) return null;
        Planetas resultado = null;
        try{
            Statement stmt = null;
            stmt = c.createStatement();
            String sql = "SELECT * FROM Planeta WHERE idp = "+idplaneta;
            ResultSet rs = stmt.executeQuery( sql );
            while ( rs.next() ) {
                int idp = rs.getInt("idp");
                String  nome = rs.getString("nome");
                int  qtdpessoasphe = rs.getInt("qtdpessoasphe");
                String localizacao = rs.getString("localizacao");
                resultado = new Planetas(idp, nome, qtdpessoasphe, localizacao);
            }
            rs.close();
            stmt.close();
            c.close();
        } catch ( Exception e ) {
            System.err.println( "ERRO DURANTE CONSULTA: getFuncionarios");
            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
        }
        return resultado;
    }
    
    public ArrayList<Funcionarios> getFuncionariosRes(String nomeplaneta){
        if( !conectar() ) return null;
        ArrayList<Funcionarios> resultado = new ArrayList();
        try{
            Statement stmt = null;
            stmt = c.createStatement();
            String sql = "SELECT nome, endereco,idf,genero,salario \n" +" FROM funcionarios\n" +
"    WHERE endereco::text LIKE '%Planeta "+nomeplaneta+"%';";
            ResultSet rs = stmt.executeQuery( sql );
            while ( rs.next() ) {
                int idf = rs.getInt("idf");
                float salario = rs.getFloat("salario");
                String endereco = rs.getString("endereco");
                String genero = rs.getString("genero");
                String nome = rs.getString("nome");
                resultado.add(new Funcionarios(idf, salario, endereco, genero, nome));
            }
            rs.close();
            stmt.close();
            c.close();
        } catch ( Exception e ) {
            System.err.println( "ERRO DURANTE CONSULTA: getPlanetasRes");
            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
        }
        return resultado;
    }
     
     public ArrayList<Funcionarios> getFuncionarios(){
        if( !conectar() ) return null;
        ArrayList<Funcionarios> resultado = new ArrayList();
        try{
            Statement stmt = null;
            stmt = c.createStatement();
            String sql = "SELECT * FROM Funcionarios ORDER BY salario";
            ResultSet rs = stmt.executeQuery( sql );
            while ( rs.next() ) {
                int idf = rs.getInt("idf");
                float salario = rs.getFloat("salario");
                String endereco = rs.getString("endereco");
                String genero = rs.getString("genero");
                String nome = rs.getString("nome");
                resultado.add(new Funcionarios(idf, salario, endereco, genero, nome));
            }
            rs.close();
            stmt.close();
            c.close();
        } catch ( Exception e ) {
            System.err.println( "ERRO DURANTE CONSULTA: getFucionarioss");
            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
        }
        return resultado;
    }
    
   
   
    
    public Funcionarios getFuncionarios(int idfun){
        if( !conectar() ) return null;
        Funcionarios resultado = null;
        try{
            Statement stmt = null;
            stmt = c.createStatement();
            String sql = "SELECT * FROM Funcionarios WHERE idf = "+idfun;
            ResultSet rs = stmt.executeQuery( sql );
            while ( rs.next() ) {
                int idf = rs.getInt("idf");
                float salario = rs.getFloat("salario");
                String endereco = rs.getString("endereco");
                String genero = rs.getString("genero");
                String nome = rs.getString("nome");
                resultado = new Funcionarios(idf, salario, endereco, genero, nome);
            }
            rs.close();
            stmt.close();
            c.close();
        } catch ( Exception e ) {
            System.err.println( "ERRO DURANTE CONSULTA: getFuncionarios");
            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
        }
        return resultado;
    }
       
    public boolean alterarFuncionarios(Funcionarios f){
        if( !conectar() ) return false;
        Funcionarios resultado = null;
        try{
            Statement stmt = null;
            stmt = c.createStatement();
            String sql = "UPDATE Funcionarios SET nome = '"+f.nome+"', genero = '"+f.genero+"', "
                    + "salario = "+f.salario+", endereco = '"+f.endereco+"' "
                    + "WHERE idf = "+f.idf;
            stmt.executeUpdate( sql );
            stmt.close();
            c.close();
        } catch ( Exception e ) {
            System.err.println( "ERRO DURANTE ATUALIZAÇÃO: alterarFuncionarios");
            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
            return false;
        }
        return true;
    }
        public boolean RemoverFuncionario(Funcionarios f) {
         if( !conectar() ) return false;
        Funcionarios resultado = null;
        try{
            Statement stmt = null;
            stmt = c.createStatement();
            String sql = (" DELETE FROM Funcionarios WHERE idf= '"+f.idf+"' ");
            stmt.executeUpdate( sql );
            stmt.close();
            c.close();
        } catch ( Exception e ) {
            System.err.println( "ERRO DURANTE Remoção: RemoverFuncionário");
            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
            return false;
        }
        return true;
    }
        public boolean RemoverPlaneta (Planetas p){
        if( !conectar() ) return false;
        Planetas resultado = null;
        try{
            Statement stmt = null;
            stmt = c.createStatement();
            String sql = (" DELETE FROM Planeta WHERE idp= '"+p.idp+"' ");
            stmt.executeUpdate( sql );
            stmt.close();
            c.close();
        } catch ( Exception e ) {
            System.err.println( "ERRO DURANTE Remoção: RemoverPlaneta");
            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
            return false;
        }
        return true;  
        }
    public boolean CadastrarFuncionario(Funcionarios f) {
         if( !conectar() ) return false;
        Funcionarios resultado = null;
        try{
            Statement stmt = null;
            stmt = c.createStatement();
            String sql = "INSERT INTO Funcionarios (idf, salario, endereco, genero, nome)"
                    + "VALUES ("+f.idf+", "+f.salario+", '"+f.endereco+"', '"+f.genero+"', '"+f.nome+"')";
            stmt.executeUpdate( sql );
            stmt.close();
            c.close();
        } catch ( Exception e ) {
            System.err.println( "ERRO DURANTE INSERÇÃO: cadastrarFuncionario");
            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
            return false;
        }
        return true;
    }
      
    public boolean CadastrarPlaneta(Planetas p) {
         if( !conectar() ) return false;
        Planetas resultado = null;
        try{
            Statement stmt = null;
            stmt = c.createStatement();
            String sql = "INSERT INTO Planeta (idp, nome, qtdPessoasPHE, localizacao)"
                    + "VALUES ("+p.idp+", '"+p.nome+"', "+p.qtdpessoasphe+", '"+p.localizacao+"')";
            stmt.executeUpdate( sql );
            stmt.close();
            c.close();
        } catch ( Exception e ) {
            System.err.println( "ERRO DURANTE INSERÇÃO: cadastrarPlaneta");
            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
            return false;
        }
        return true;
    }
    
    public boolean alterarPlaneta(Planetas p){
        if( !conectar() ) return false;
        Planetas resultado = null;
        try{
            Statement stmt = null;
            stmt = c.createStatement();
            String sql = "UPDATE Planeta SET idp = "+p.idp+", nome= '"+p.nome+"', "
                    + "qtdPessoasPHE = "+p.qtdpessoasphe+", localizacao = '"+p.localizacao+"' "
                    + "WHERE idp = "+p.idp;
            stmt.executeUpdate( sql );
            stmt.close();
            c.close();
        } catch ( Exception e ) {
            System.err.println( "ERRO DURANTE ATUALIZAÇÃO: alterarPlaneta");
            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
            return false;
        }
        return true;
    }
}
