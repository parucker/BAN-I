package app;
import EDA.Planetas;
import javax.swing.JOptionPane;


/**
 *
 * @author henri
 */
public class CadastrarPlaneta extends javax.swing.JFrame {
        boolean ehCadastro = true;

    /**
     * Creates new form CadastrarPlaneta
     */
    public CadastrarPlaneta(boolean cadastrar) {
        ehCadastro = cadastrar;
        initComponents();
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/planet-saturn.png")));
        if( cadastrar ){
            rotuloTitulo.setText("Cadastrar Planeta");
            botaoAcao.setText("Cadastrar");
        }
        else{
            rotuloTitulo.setText("Alterar Planeta");
            botaoAcao.setText("Consultar");
            alterarEdicaoCampos( false );
            textFieldIdp.setEnabled( true );

        }
    }

  private void getCodigoPlanetas(){
        Planetas p = null;
        do{
            String entrada = JOptionPane.showInputDialog(this, "Digite o código do planeta ou 0 (zero)\n"
                + "para retornar ao menu principal.", "Alterar planeta",
                JOptionPane.INFORMATION_MESSAGE);
            System.out.println( entrada );
            
            if( entrada==null || entrada.equals("0") ){
                this.dispose();
                Main.showMainWindow();
            }
            
            // tenta converter o texto digitado para número
            int idp = 0;
            try{
                idp = Integer.parseInt( entrada );
            } catch(NumberFormatException ex){
                JOptionPane.showMessageDialog(this, "Você não digitou um número estrupício!", "Erro", JOptionPane.ERROR_MESSAGE);
            }
            
            if( idp != 0 )
                p = Main.getBD().getPlanetas( idp );
        } while( p == null );             
    }
  
    private void tratarCadastro(){
        if( verificarErros() ){
                showErroPreenchimento();
                return;
            }
            int idp;
            int qtdphe;
            try{
                idp = Integer.parseInt( textFieldIdp.getText() );
                qtdphe = Integer.parseInt( textFieldqtdPhe.getText() );
            } catch ( NumberFormatException ex ){
                showErroPreenchimento();
                return;
            }
            
            Planetas p = new Planetas(idp, textFieldNome.getText(), qtdphe, textFieldLocalizacao.getText());
            
            boolean resultado = Main.getBD().CadastrarPlaneta( p );
            if( resultado == false ){
                showErroBD();
                return;
            }
            int opcao = JOptionPane.showConfirmDialog(this, "Planeta adicionado com sucesso.\n"
                    + "Deseja adicionar outro registro?", "Operação Realizada com Sucesso", JOptionPane.YES_NO_OPTION);
            if( opcao == JOptionPane.YES_OPTION ){
                limpaCampos();
            }
            else{
                Main.showMainWindow();
                this.dispose();
            }
    }
    
    
    
    private void tratarAlteracao(){
        if( textFieldIdp.isEnabled() ){
            int idp;
            try{
                idp = Integer.parseInt( textFieldIdp.getText() );
            } catch ( NumberFormatException ex ){
                showErroPreenchimento();
                return;
            }

            Planetas p = Main.getBD().getPlanetas( idp );
            if( p==null ){
                JOptionPane.showMessageDialog(this, "Nenhum planeta foi encontrado com este código!", "Resultado", JOptionPane.INFORMATION_MESSAGE);
            }
            else{
                textFieldIdp.setText( ""+p.idp );
                textFieldNome.setText( p.nome );
                textFieldqtdPhe.setText( ""+p.qtdpessoasphe );
                textFieldLocalizacao.setText( p.localizacao );
                alterarEdicaoCampos( true );
                textFieldIdp.setEnabled(false );
                botaoAcao.setText("Alterar");
            }
        }

        else{ // realizar alteração na tabela
            if( verificarErros() ){
                showErroPreenchimento();
                return;
            }
            int idp;
            int qtdphe;
            try{
                idp = Integer.parseInt( textFieldIdp.getText());
                qtdphe = Integer.parseInt( textFieldqtdPhe.getText() );
            } catch ( NumberFormatException ex ){
                showErroPreenchimento();
                return;
            }
            Planetas p = new Planetas(idp, textFieldNome.getText(), qtdphe, textFieldLocalizacao.getText());          
            boolean resultado = Main.getBD().alterarPlaneta(p);
            if( resultado == false ){
                showErroBD();
                return;
            }
            int opcao = JOptionPane.showConfirmDialog(this, "Dados alterados com sucesso.\n"
                    + "Deseja alterar outro registro?", "Operação Realizada com Sucesso", JOptionPane.YES_NO_OPTION);
            if( opcao == JOptionPane.YES_OPTION ){
                limpaCampos();
                alterarEdicaoCampos( false );
                textFieldIdp.setEnabled( true );
                botaoAcao.setText("Consultar");
            }
            else{
                Main.showMainWindow();
                this.dispose();
            }
        }
    }
    
    private boolean verificarErros(){
        if( textFieldNome.getText().length()==0 && textFieldLocalizacao.getText().length()>1 ){
            showErroPreenchimento();
            return true;
        }
        return false;
    }
    
    private void showErroPreenchimento(){
        JOptionPane.showMessageDialog(this, "Verifique o preenchimento dos dados!", "Erro", JOptionPane.ERROR_MESSAGE);
    }
    private void showErroBD(){
        JOptionPane.showMessageDialog(this, "Ocorreu algum erro ao registrar dados no BD!", "Erro", JOptionPane.ERROR_MESSAGE);
    }
    
    
    
    
    private void limpaCampos(){
        textFieldIdp.setText("");
        textFieldNome.setText("");
        textFieldqtdPhe.setText("");
        textFieldLocalizacao.setText("");
    }
    
    
    
    private void alterarEdicaoCampos(boolean opcao){
        textFieldIdp.setEnabled( opcao );
        textFieldNome.setEnabled( opcao );
        textFieldqtdPhe.setEnabled( opcao );
        textFieldLocalizacao.setEnabled( opcao );
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        textFieldNome = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        botaoAcao = new javax.swing.JButton();
        botaoCancelar = new javax.swing.JButton();
        textFieldqtdPhe = new javax.swing.JTextField();
        textFieldLocalizacao = new javax.swing.JTextField();
        textFieldIdp = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        rotuloTitulo = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel6.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 10)); // NOI18N
        jLabel6.setText("IDP:");

        jLabel7.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 10)); // NOI18N
        jLabel7.setText("Nome:");

        textFieldNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textFieldNomeActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 10)); // NOI18N
        jLabel10.setText("Localização:");

        botaoAcao.setBackground(new java.awt.Color(204, 255, 204));
        botaoAcao.setText("acao");
        botaoAcao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botaoAcaoActionPerformed(evt);
            }
        });

        botaoCancelar.setBackground(new java.awt.Color(255, 153, 153));
        botaoCancelar.setText("Voltar");
        botaoCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botaoCancelarActionPerformed(evt);
            }
        });

        textFieldqtdPhe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textFieldqtdPheActionPerformed(evt);
            }
        });

        textFieldIdp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textFieldIdpActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 10)); // NOI18N
        jLabel11.setText("População:");

        rotuloTitulo.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        rotuloTitulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/planet-saturn.png"))); // NOI18N
        jLabel1.setText("Xploration");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(textFieldqtdPhe)
                    .addComponent(textFieldIdp, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel7)
                    .addComponent(jLabel10))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(botaoCancelar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(botaoAcao, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(textFieldNome, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textFieldLocalizacao, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(49, 49, 49))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(rotuloTitulo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(24, 24, 24))
            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(rotuloTitulo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(textFieldIdp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(textFieldNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textFieldqtdPhe, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11)
                    .addComponent(jLabel10)
                    .addComponent(textFieldLocalizacao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(56, 56, 56)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botaoAcao)
                    .addComponent(botaoCancelar))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void textFieldIdpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textFieldIdpActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textFieldIdpActionPerformed

    private void textFieldqtdPheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textFieldqtdPheActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textFieldqtdPheActionPerformed

    private void textFieldNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textFieldNomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textFieldNomeActionPerformed

    private void botaoCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botaoCancelarActionPerformed
        int acao = JOptionPane.showConfirmDialog(this, "Você tem certeza que deseja voltar?\n"
                + "Todos os dados digitados serão perdidos.", "Confirmação",
                JOptionPane.YES_NO_OPTION );
        
        if( acao == JOptionPane.NO_OPTION ) return;
        
        Main.showMainWindow();
        this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_botaoCancelarActionPerformed

    private void botaoAcaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botaoAcaoActionPerformed
        if( ehCadastro ){
            tratarCadastro();
        }
        
        else{ //é alteração
            tratarAlteracao();
        }    // TODO add your handling code here:
    }//GEN-LAST:event_botaoAcaoActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botaoAcao;
    private javax.swing.JButton botaoCancelar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel rotuloTitulo;
    private javax.swing.JTextField textFieldIdp;
    private javax.swing.JTextField textFieldLocalizacao;
    private javax.swing.JTextField textFieldNome;
    private javax.swing.JTextField textFieldqtdPhe;
    // End of variables declaration//GEN-END:variables
}
