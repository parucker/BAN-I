/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EDA;

/**
 *
 * @author udesc
 */
public class  Funcionarios {
    public int idf;
    public float salario;
    public String endereco;
    public String genero;
    public String nome;
    
    public Funcionarios(int idfuncionario, float salariof, String enderecof, String generof, String nomef){
        idf = idfuncionario;
        salario = salariof;
        endereco = enderecof;
        genero = generof;
        nome = nomef;
    }

   
    
}
