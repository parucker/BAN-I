/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EDA;

/**
 *
 * @author udesc
 */
public class Planetas {
    public int idp;
    public String nome;
    public int qtdpessoasphe;
    public String localizacao;
    
    public Planetas(int idplaneta, String nomep, int qtdpessoasp, String locap){
        idp = idplaneta;
        nome = nomep;
        qtdpessoasphe = qtdpessoasp;
        localizacao = locap;
    }
}
